import numpy as np
from typing import Tuple

def run_monte_carlo_var(
    current_price: float,
    mu: float = 0.0,
    sigma: float = 0.30,
    T: float = 1/252,  # 1 day
    num_simulations: int = 10000,
    confidence: float = 0.95
) -> Tuple[float, float]:
    """
    Run Monte Carlo simulation and return VaR and ES
    
    Returns:
        (var_95, es_95) as a tuple
    """
    final_prices = simulate_gbm(current_price, mu, sigma, T, num_simulations)
    var_95, var_threshold, losses = calculate_var(current_price, final_prices, confidence)
    es_95 = calculate_es(var_threshold, losses)    
    return (var_95, es_95)


def simulate_gbm(S0, mu, sigma, T, num_simulations):
    """
    Simulate stock prices using Geometric Brownian Motion
    
    Returns:
        Array of final prices (one per simulation)
    """
    # TODO: Implement this
    z = np.random.standard_normal(num_simulations)  # Generate random shocks
    drift = (mu - 0.5 * sigma**2) * T # Calculate drift
    diffusion = sigma * np.sqrt(T) * z  # Calculate diffusion
    ST = S0 * np.exp(drift + diffusion)  # GBM formula
    return ST

def calculate_var(initial_value, simulated_values, confidence=0.95):
    """
    Calculate Value at Risk (VaR)
    VaR at 95% confidence means we are 95% confident that losses will NOT exceed this amount.
    
    Args:
        initial_value: Starting portfolio value
        simulated_values: Array of simulated ending values
        confidence: Confidence level (0.95 = 95%)
    
    Returns:
        Tuple of (var_amount, var_percentile, losses_array)
        - var_amount: VaR as a positive loss amount (always >= 0)
        - var_percentile: The actual percentile value from distribution
        - losses: Array of calculated losses for further analysis
    """
    # Calculate losses: positive = loss, negative = gain
    losses = initial_value - simulated_values
    
    # Find the confidence percentile of the loss distribution
    # For 95% confidence, this is the 95th percentile of losses
    # This represents the loss level below which 95% of outcomes fall
    var_percentile = np.percentile(losses, confidence * 100)
    
    # VaR should always be reported as a positive number (amount of potential loss)
    var_amount = max(0, var_percentile)
    
    return var_amount, var_percentile, losses
    

def calculate_es(var_threshold, losses):
    """
    Calculate Expected Shortfall (Conditional Value at Risk)
    ES is the average loss in the worst-case scenarios (tail of the distribution)
    
    Args:
        var_threshold: The VaR threshold (loss level at confidence level)
        losses: Array of all simulated losses
    
    Returns:
        ES as a positive number (average loss in worst cases)
    """
    # We want to find the average loss of all simulations where the loss is greater than or equal to the VaR threshold. 
    # This means we are looking at the tail of the loss distribution that exceeds the VaR level.
    # Average of all losses exceeding VaR (worst 5% for 95% confidence)
    # Use > (strictly greater) because ES is the average of losses that EXCEED the VaR threshold
    tail_losses = losses[losses > var_threshold]
    
    # If no tail losses found (edge case), use >= as fallback
    if len(tail_losses) == 0:
        tail_losses = losses[losses >= var_threshold]
    
    es = np.mean(tail_losses) if len(tail_losses) > 0 else var_threshold
    
    return max(0, es)